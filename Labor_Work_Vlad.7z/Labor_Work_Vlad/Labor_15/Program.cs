﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;

namespace Labor_15
{
    class Mains
    {
        enum Marks {  very_bad, bad, satisfactory, good, excellent, NoSuchMark};
        static void Main(string[] args)
        {
            int x = (int)Marks.satisfactory;
            Console.WriteLine($" And also the characteristic satisfactory is for: {x} mark");

            Console.WriteLine("Введите отметку");
            int mark = int.Parse( Console.ReadLine() );
            Marks characteristic = Marks.very_bad;
            Cheack(mark, ref characteristic);
            WriteLine($"is {characteristic}");

            // Задание 2
            Console.WriteLine("Введите натуральные числа N и a:");
            int n = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.Write(a + i + " ");
            }

            //Задание 3
            int[] pos = { -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5 };

            Console.WriteLine("\nПоследовательность:");
            Console.WriteLine(string.Join(" ", pos));

            var Plus = pos.Where(a => a > 0);
            Console.WriteLine("1) " + string.Join(" ", Plus));

            var Five = pos.Where(a => a % 5 == 0);
            Console.WriteLine("2) " + string.Join(" ", Five));

            var Nechet = pos.Where(a => a % 2 != 0);
            Console.WriteLine("3) " + string.Join(" ", Nechet));

            //Задание 4
            int[] mas = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Console.WriteLine(string.Join(" ", mas));
            var mas1 = mas.Select(a => a + 2);
            Console.WriteLine(string.Join(" ", mas1));
        }

        static void Cheack(int mark, ref Marks characteristic)
        {
            switch (mark) 
            {
                case 1: 
                    characteristic = Marks.very_bad; break;
                case 2:
                    characteristic = Marks.bad; break;
                case 3:
                    characteristic = Marks.satisfactory; break;
                case 4:
                    characteristic = Marks.good; break;
                case 5:
                    characteristic = Marks.excellent; break;
                default:
                    Console.WriteLine("Нэту (");
                    characteristic = Marks.NoSuchMark; break;
            }
        }

       
    }
}