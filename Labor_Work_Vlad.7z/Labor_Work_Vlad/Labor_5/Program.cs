﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_5
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Порции кофе: 1-маленькая, 2-средняя, 3-большая");
            Console.WriteLine("Выберите");
            String str = Console.ReadLine();
            int price = 0;
            switch (str)
            {
                case "1": price += 25;
                    break;
                case "2": price += 50;
                    break;
                case "3": price += 75;
                    break;
                default: Console.WriteLine("Нет в меню");
                        break;
            } 
            if (price !=  0)
            {
            Console.WriteLine($"{price} руб.");
            }
            // Задание 8
            Console.WriteLine("от 1 до 7");
            String s = Console.ReadLine();
            String day = "";
            switch (s)
            {
                case "1": day = "Monday";
                    break;
                case "2": day = "Tuesday";
                    break;
                case "3": day = "Wednesday";
                    break;
                case "4": day = "Thursday";
                    break; 
                case "5": day = "Friday";
                    break;
                case "6": day = "Saturday";
                    break;
                case "7": day = "Sunday";
                    break; 
                default : Console.WriteLine("Нет такого дня");
                    break;
            }
            Console.WriteLine(day);
        }
    }
}
