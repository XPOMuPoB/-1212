﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;

namespace Labor_17
{
    class Mains
    {
       static void Main(string[] args)
       {
            int[] arr = new int[10];
            FillRandomArray(arr, -10, 15);
            PrintArray(arr);
            DivisibleBy3(arr);

            int[] array = new int[15];
            FillAndPrintArray(array);
            Console.WriteLine("Введите искомое число:");
            int N = int.Parse(Console.ReadLine());
            FindN(array, N);

            double[] arrs = new double[10];
            FillArray(arrs);
            PrintSum(arrs);
        }
       
       static void FillRandomArray(int[] arr, int minValue = -10, int maxValue = 15)
       {
            Random rand = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.Next(minValue, maxValue);
            }
       }
        static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++) 
            {
                Write($"{arr[i]} ");
            }
        }
        static void DivisibleBy3(int[] arr)
        {
            int count = 0;
            Console.WriteLine($"\nкратные 3: ");
            for (int i = 0; i < arr.Length; i++) 
            {
                if (arr[i] % 3 == 0)
                {
                    Write($"{arr[i]} ");
                    count++;
                }
            }
            Console.WriteLine();
            Console.WriteLine($"Количество элементов, кратных 3: {count}");
        }
        // Задание 2
        static void FillAndPrintArray(int[] arr)
        {
            Random random = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next(1, 11);
            }

            Console.WriteLine("Массив:");
            Console.WriteLine(string.Join(", ", arr));
        }
        static void FindN(int[] arr, int N)
        {
            bool found = false;
            foreach (int x in arr)
            {
                if (x == N)
                {
                    found = true;
                    break; 
                }
            }
            if (found)
            {
                Console.WriteLine("да");
            }
            else
            {
                Console.WriteLine("нет");
            }
        }
        // Задание 3
        static void FillArray(double[] arrs)
        {
            Random rand = new Random();

            for (int i = 0; i < arrs.Length; i++)
            {
                arrs[i] = rand.NextDouble() * 10 - 5;
            }

            Console.WriteLine("Массив:");
            foreach (double num in arrs)
            {
                Console.Write($"{num:F2} ");
            }
        }
        static void PrintSum(double[] arrs)
        {
            Console.WriteLine("\nСуммы троек рядом стоящих элементов:");
            for (int i = 0; i < arrs.Length - 2; i++)
            {
                double sum = arrs[i] + arrs[i + 1] + arrs[i + 2];
                Console.WriteLine($"{i + 1}, {i + 2}, {i + 3}: {sum:F2}");
            }
        }
    }
}