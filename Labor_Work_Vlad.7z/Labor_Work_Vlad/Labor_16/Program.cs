﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Labor_16
{
    class Mains
    {
        static void Main(string[] args)
        {
            int[] a = new int[] { -1, -2, 3, 4, 5, 6, 7};
            
            int countOdd = 0;
            int countPos = 0;
            CountOddPos(a, ref countOdd, ref countPos);
            Print(a);
            WriteLine($"нечетных {countOdd}, положительных {countPos}");

            double[] b = new double[] { 1.1, -2.3, 3.7, 4.1, 5.6, 6.1, 7.1 };
            double max = b[0];
            double min = b[0];
            FindMaxMin(b, ref max, ref min);
            PrintArray(b);
            Console.WriteLine($"min: {min}, max {max}");
        }

        static void Print(int[] arr)
        {
            Console.WriteLine("Массив");
            foreach (var x in arr)
                Write(x + " ");
            Console.WriteLine();
        }
        static void CountOddPos(int[] arr, ref int countOdd, ref int countPos)
        {
            foreach (var x in arr)
                    {
                        if (x % 2 != 0)
                            countOdd++;
                        if (x > 0)
                            countPos++; 
                    }
        }
        // Задание 1
        static void FindMaxMin(double[] b, ref double max, ref double min)
        {
             foreach (double num in b)
             {
                 if (num > max)
                 {
                max = num;
                 }
      
                if (num < min)
                {
                min = num;
                }
             }
        }

        static void PrintArray(double[] array)
        {
            Console.WriteLine(string.Join(", ", array));
        }
    }
}