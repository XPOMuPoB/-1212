﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Labor_10
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите последовательность чисел и закончите ввод нулем");
            int numb;
            int min = int.MaxValue;
            try
            {
                do
                {
                    numb = Int32.Parse(Console.ReadLine());
                    if (numb < min && numb != 0)
                    {
                        min = numb;
                    }
                }
                while (numb != 0);{ }
                Console.WriteLine($"Минимальное {min}");
            }
            catch (FormatException e) 
            {
                Console.WriteLine(e.Message + "Повторите");
            }

            // Задание 5
            int max = 0;
            int index = 0;
            int currentIndex = 0;
            int number;
            Console.WriteLine("Введите последовательность чисел и закончите ввод нулем:");

            do
            {
                number = Int32.Parse(Console.ReadLine());

                if (number != 0 && number > max)
                {
                    max = number;
                    index = currentIndex;
                }
            }
            while (number != 0); { }
            Console.WriteLine($"Максимальное число {max}, его порядковый номер {index}");
        }
    }
}