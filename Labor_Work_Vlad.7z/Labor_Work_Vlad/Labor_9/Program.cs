﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_12
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число и степень");
            int a = Int32.Parse(Console.ReadLine());
            int b = Int32.Parse(Console.ReadLine());
            Console.WriteLine(GetPow(a, b));

            Console.WriteLine("Введите координаты 1 точки");
            double x1 = Double.Parse(Console.ReadLine());
            double y1 = Double.Parse(Console.ReadLine());

            Console.WriteLine("Введите координаты 2 точки");
            double x2 = Double.Parse(Console.ReadLine());
            double y2 = Double.Parse(Console.ReadLine());

            double res1 = Distance(x1, y1, x2, y2);
            Console.WriteLine("Ответ: " + res1);
        }
        static int GetPow(int baseNum, int powNum) 
        {
            int res = 1;
            for (int i = 0; i < powNum; i++)
            {
                res = res * baseNum;
            }
            return res;
        }
        static double Distance (double x1, double y1, double x2, double y2)
        {
            double res1 = 0;
            res1 = Math.Sqrt(Math.Pow((x2 - x1), 2) + Math.Pow((y2 - y1), 2));
            return res1;
        }
    }
}