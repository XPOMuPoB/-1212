﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace Labor_11
{
    class Mains
    {
        static void Sum (int first, int second)
        {
            int sum = first + second;
            Console.WriteLine($"Сумма {first} + {second} = {sum}");
        }
        static double Perimeter(double a, double b, double c) 
        {
            double P = a + b + c;
            return P;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("2 числа");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());; 
            
            Sum(a, b);

            Console.WriteLine("Введите стороны треугольника");
            double a1 = double.Parse(Console.ReadLine());
            double b1 = double.Parse(Console.ReadLine());
            double c1 = double.Parse(Console.ReadLine());

            double P = Perimeter(a1, b1, c1);
            Console.WriteLine("Периметр = " + P);
        }
        

    }
}
