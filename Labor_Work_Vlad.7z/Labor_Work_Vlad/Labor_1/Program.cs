﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_2
{
    class Mains
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            n++;
            Console.WriteLine(n); 
           
            // Задание 2
            Console.WriteLine("Введите два числа");
            double a = double.Parse(Console.ReadLine());
            double b = double.Parse(Console.ReadLine());

            a = (a + b) / 2;
            Console.WriteLine("Среднее = " + a);

            // Задание 3
            Console.WriteLine("Введите сторону треугольника");
            double c = double.Parse(Console.ReadLine());
            c = (Math.Pow(c, 2) * Math.Sqrt(3)) / 4;
            Console.WriteLine("Площадь = " + c);
        }
    }
}
