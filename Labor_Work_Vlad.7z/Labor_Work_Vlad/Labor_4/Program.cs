﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Labor_4
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            int numb = Int32.Parse(Console.ReadLine());
            if (numb % 2 == 0) 
            {
                Console.WriteLine("Четное");
            }
            else
            {
                Console.WriteLine("Нечетное");
            }

            //Задание 1
            Console.WriteLine("Введите число");
            int num = Int32.Parse(Console.ReadLine());
            if (num > 0)
            {
                Console.WriteLine("положительное");
            }
            else { Console.WriteLine("отрицательное"); }

            //Задание 2
            Console.WriteLine("Введите число");
            int num1 = Int32.Parse(Console.ReadLine());
            int ten = Math.Abs(num1) / 10;
            int one = Math.Abs(num1) % 10;
            Console.WriteLine("Десятки " + ten + " Единицы " + one);

            //Задание 3
            Console.WriteLine("Введите трехзначное число");
            int number = int.Parse(Console.ReadLine());
            int absNumber = Math.Abs(number);

            int sto = absNumber / 100;
            int ones = absNumber % 10;

            int res1 = sto * 100 + ones;
            if (number < 0)
            {
                res1 = -res1;
            }
            Console.WriteLine(res1);
            //Задание 4
            Console.WriteLine("Введите 3 числа");
            string[] nums = Console.ReadLine().Split(' ');
            int x1 = Convert.ToInt32(nums[0]);
            int x2 = Convert.ToInt32(nums[1]);
            int x3 = Convert.ToInt32(nums[2]);

            Console.WriteLine($"{x1 != x2 && x1 != x3 && x2 != 3 || x1 == x2 && x1 == x3 && x2 == x3}");

            //Задание 5
            Console.WriteLine("Введите 3 числa");
            string[] numy = Console.ReadLine().Split(' ');
            double a1 = Convert.ToDouble(numy[0]);
            double a2 = Convert.ToDouble(numy[1]);
            double a3 = Convert.ToDouble(numy[2]);
           
            if (a1 + a2 > a3 && a1 + a3 > a2 && a2 + a3 > a1)
            {
                double p = (a1 + a2 + a3) / 2;
                double res2 = Math.Sqrt(p * (p - a1) * (p - a2) * (p - a3));
                Console.WriteLine("существует" + res2);
            }
            else
            {
                Console.WriteLine("Такого нет (");
            }
        }
    }
}